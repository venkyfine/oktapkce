//
//  ViewController.swift
//  AppUsingPKCE
//
//  Created by Eidinger, Marco on 12/16/21.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func signIn(_ sender: Any) {
        // Example-specific values
        
        
        let bundleIdentifier = Bundle.main.bundleIdentifier!
        let auth0domain = "wmlogindev.wm.com"
        let authorizeURL = "https://wmlogindev.wm.com/oauth2/aus15dihowfOxhzwk0h8/v1/authorize"
            //"https://\(auth0domain)/authorize"
        let tokenURL = "https://wmlogindev.wm.com/oauth2/aus15dihowfOxhzwk0h8/v1/token"
        //"https://\(auth0domain)/oauth/token"
        let clientId = "0oa1aync38enWU10h0h8"
        //"txfpmPJryrScEL9bu0jnHT55lFokXftO"
        let redirectUri = "\(bundleIdentifier):/callback"

        // Example-agnostic code
        let parameters = OAuth2PKCEParameters(authorizeUrl: authorizeURL,
                                        tokenUrl:tokenURL,
                                        clientId: clientId,
                                        redirectUri: redirectUri,
                                        callbackURLScheme: bundleIdentifier)

        let authenticator = OAuth2PKCEAuthenticator()
        authenticator.authenticate(parameters: parameters) { result in
            var message: String = ""
            switch result {
            case .success(let accessTokenResponse):
                message = accessTokenResponse.access_token
            case .failure(let error):
                message = error.localizedDescription
            }

            let alert = UIAlertController(
                title: "Result",
                message: message,
                preferredStyle: .alert)
            alert.addAction(.init(title: "Ok", style: .default, handler: nil))
            DispatchQueue.main.async {
                self.present(alert, animated: true, completion: nil)
            }
        }
    }

}

